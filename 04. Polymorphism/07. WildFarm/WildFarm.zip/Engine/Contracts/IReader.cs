﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Engine.Contracts
{
    public interface IReader
    {
        public string ReadLine();
    }
}
