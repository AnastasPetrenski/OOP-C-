﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Enums
{
    public enum AskingForFoodSounds
    {

    }
}
