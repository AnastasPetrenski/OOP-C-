﻿using Raiding.Common;
using System;

namespace Raiding.Models
{
    public class Rogue : BaseHero
    {
        public Rogue(string name) : base(name)
        {
            this.Power = GlobalConstants.RoguePower;
        }

        //Rogue – "{Type} – {Name} hit for {Power} damage"
        public override string CastAbility()
        {
            return $"{this.GetType().Name} - {Name} hit for {Power} damage";
        }
    }
}
