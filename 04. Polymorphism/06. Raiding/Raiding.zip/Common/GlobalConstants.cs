﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Common
{
    public class GlobalConstants
    {
        public const int DruidPower = 80;
        public const int RoguePower = 80;
        public const int PaladinPower = 100;
        public const int WarriorPower = 100;

    }
}
