﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Product product = new Product("product", 2.30m);
            //Console.WriteLine(product.GetType());
            //Console.WriteLine(product.Name);
            //Console.WriteLine(product.Price);

            //Coffee coffee = new Coffee("coffee", 10);
            //Console.WriteLine(coffee.GetType());
            //Console.WriteLine(coffee.Name);
            //Console.WriteLine(coffee.Price);


        }
    }
}
