﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    public class Child : Person
    {
        //private int age;

        public Child(string name, int age) : base(name, age)
        {

        }

        //public override int Age
        //{
        //    get
        //    {
        //        return this.age;
        //    }
        //    set
        //    {
        //        if (value >= 0 && value < 16)
        //        {
        //            this.age = value;
        //        }
        //        else
        //        {
        //            throw new ArgumentException("Can not be more than 15");
        //        }
        //    }
        //}
    }
}
