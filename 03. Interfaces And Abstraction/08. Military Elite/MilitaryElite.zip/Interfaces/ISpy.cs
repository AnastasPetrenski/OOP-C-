﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP03InterfacesAndAbstraction.Interfaces
{
    public interface ISpy
    {
        public int CodeNumber { get; }
    }
}
