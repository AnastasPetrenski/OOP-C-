﻿using OOP03InterfacesAndAbstraction.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace OOP03InterfacesAndAbstraction.Interfaces
{
    public interface ISpecialisedSoldier 
    {
        string CorpsEnum { get; }
    }
}
