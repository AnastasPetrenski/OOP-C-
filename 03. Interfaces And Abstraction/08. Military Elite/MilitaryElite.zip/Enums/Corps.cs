﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP03InterfacesAndAbstraction.Enums
{
    public enum Corps
    {
        Airforces = 1,
        Marines = 2
    }
}
