﻿
namespace CollectionHierarchy.Interfaces
{
    public interface IAddRemoveCollection<T>
    {
        public T Remove();
    }
}
