﻿
namespace CollectionHierarchy.Common
{
    public static class GlobalConstants
    {
        public const string IndexOutOfRangeExpMsg = "{0} Out Of Range! {0} can not be bigger than {1}";

        public const string EmptyArrayExpMsg = "Array is empty!";

    }
}
