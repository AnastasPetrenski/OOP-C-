﻿namespace Shapes
{
    public interface IDrawable
    {
        public string Draw();
    }
}
