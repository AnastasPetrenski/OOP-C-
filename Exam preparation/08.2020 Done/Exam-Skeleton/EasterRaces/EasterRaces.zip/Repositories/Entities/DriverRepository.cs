﻿namespace EasterRaces.Repositories.Entities
{
    using EasterRaces.Models.Drivers.Contracts;

    public class DriverRepository : Repository<IDriver>
    {   
    }
}
