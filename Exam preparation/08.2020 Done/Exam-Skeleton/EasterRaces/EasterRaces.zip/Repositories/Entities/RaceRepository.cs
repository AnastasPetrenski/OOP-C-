﻿namespace EasterRaces.Repositories.Entities
{
    using EasterRaces.Models.Races.Contracts;

    public class RaceRepository : Repository<IRace>
    {
    }
}
