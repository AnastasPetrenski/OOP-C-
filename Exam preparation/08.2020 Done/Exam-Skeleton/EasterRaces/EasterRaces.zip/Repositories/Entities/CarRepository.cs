﻿namespace EasterRaces.Repositories.Entities
{
    using EasterRaces.Models.Cars.Contracts;

    public class CarRepository : Repository<ICar>
    {   
    }
}
