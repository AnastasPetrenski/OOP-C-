﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bakery.Models.BakedFoods
{
    public class Cake : Food
    {
        private const int InitialBreadPortion = 245;

        public Cake(string name, decimal price)
            : base(name, InitialBreadPortion, price)
        {
        }
    }
}
