﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FootballTeamGenerator
{
    public class Player
    {
        private string name;
        private Stat stats;

        public Player(string name, string[] stats)
        {
            this.Name = name;
            this.stats = new Stat(stats);
        }

        public string Name 
        {
            get => this.name;
            set
            {
                if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("A name should not be empty.");
                }

                this.name = value;
            }
        }

        public double Level => this.stats.Average();
    }
}