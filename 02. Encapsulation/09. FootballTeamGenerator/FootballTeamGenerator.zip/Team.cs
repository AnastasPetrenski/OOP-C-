﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FootballTeamGenerator
{
    public class Team
    {
        private string name;
        private List<Player> players;
        private double rating;

        public Team(string name)
        {
            this.Name = name;
            this.players = new List<Player>();
            League.AddTeam(this);
        }

        public int NumberOfPlayers => players.Count;
        public string Name 
        {
            get => this.name;
            set
            {
                if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("A name should not be empty.");
                }

                this.name = value;
            }
        }

        public double Rating => GetRating();

        internal double GetRating()
        {

            if (this.players.Count > 0)
            {
                var totalRating = this.players.Sum(p => p.Level);
                var totalPlayers = this.players.Count;
                var average = Math.Round(totalRating / totalPlayers);
                return average;
            }
            else
            {
                return 0;
            }
        }

        public void AddPlayer(Player player)
        {
            players.Add(player);
        }

        public void RemovePlayer(string teamName, string playerName)
        {

            if (!players.Any(t => t.Name == playerName))
            {
                throw new ArgumentException($"Player {playerName} is not in {teamName} team.");
            }

            players.RemoveAll(p => p.Name == playerName);
        }
    }
}
